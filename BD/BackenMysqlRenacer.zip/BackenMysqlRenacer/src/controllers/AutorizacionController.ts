import { Request, Response } from 'express';

import pool from '../database';
import { AutorizacionModel } from '../models/autorizacion.model';

class AutorizacionController {}

const autorizacionController = new AutorizacionController();
export default autorizacionController;
