export default {
  // database: {
  //   host: '50.87.253.191',
  //   user: 'sistemo0_bani',
  //   password: 'yapeyyurijcuna',
  //   database: 'sistemo0_bd_administracion-renacer',
  //   port: 3306,
  // },

  database: {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'bd_renacer-administracion',
  },
};
