export class DetalleAutorizacionSolesModel {
  Id_DetalleAutorizacionSoles: any;
  Id_Autorizacion: Number;
  Id_SR: Number;
  Monto: Number;

  constructor() {
    this.Id_DetalleAutorizacionSoles = null;
    this.Id_Autorizacion = 0;
    this.Id_SR = 0;
    this.Monto = 0;
  }
}
