export class TipoRegistroModel {
  Id_TipoRegistro: any;
  Codigo_TipoRegistro: String;
  Descripcion: String;

  constructor() {
    this.Id_TipoRegistro = null;
    this.Codigo_TipoRegistro = '';
    this.Descripcion = '';
  }
}
