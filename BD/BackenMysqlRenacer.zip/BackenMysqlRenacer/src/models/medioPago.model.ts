export class MedioPagoModel {
  Id_MedioPago: any;
  Codigo_MedioPago: String;
  Descripcion: String;

  constructor() {
    this.Id_MedioPago = null;
    this.Codigo_MedioPago = '';
    this.Descripcion = '';
  }
}
