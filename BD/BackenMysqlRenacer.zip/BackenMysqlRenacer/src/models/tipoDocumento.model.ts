export class TipoDocumentoModel {
  Id_TipoDocumento: any;
  Codigo_TipoDocumento: String;
  Descripcion: String;
  Codigo_TipoRegistro: String;

  constructor() {
    this.Id_TipoDocumento = null;
    this.Codigo_TipoDocumento = '';
    this.Descripcion = '';
    this.Codigo_TipoRegistro = '';
  }
}
