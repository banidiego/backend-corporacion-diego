export class TipoDocumentoIdentidadModel {
  Id_TipoDocumentoIdentidad: any;
  Codigo_TipoDocumentoIdentidad: String;
  Descripcion: String;

  constructor() {
    this.Id_TipoDocumentoIdentidad = null;
    this.Codigo_TipoDocumentoIdentidad = '';
    this.Descripcion = '';
  }
}
